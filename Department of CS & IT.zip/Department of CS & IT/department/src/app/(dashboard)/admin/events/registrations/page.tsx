import React from "react";

const EventRegistrationsPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Event Registrations</h1>
      <p className="text-gray-600">Manage event registrations here.</p>
    </div>
  );
};

export default EventRegistrationsPage; 