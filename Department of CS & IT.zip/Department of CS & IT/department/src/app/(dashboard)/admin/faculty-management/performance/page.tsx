import React from "react";

const FacultyPerformancePage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Faculty Performance Evaluation</h1>
      <p className="text-gray-600">Evaluate and track faculty performance here.</p>
    </div>
  );
};

export default FacultyPerformancePage; 