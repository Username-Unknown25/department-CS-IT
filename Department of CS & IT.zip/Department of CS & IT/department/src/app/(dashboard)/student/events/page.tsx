import React from "react";

const StudentEventsPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">My Events</h1>
      <p className="text-gray-600">View and register for department events here.</p>
    </div>
  );
};

export default StudentEventsPage; 