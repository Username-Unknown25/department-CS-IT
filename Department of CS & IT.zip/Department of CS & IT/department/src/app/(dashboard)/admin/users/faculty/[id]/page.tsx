import React from "react";

const FacultyProfilePage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Faculty Profile</h1>
      <p className="text-gray-600">View and edit faculty details here.</p>
    </div>
  );
};

export default FacultyProfilePage; 