import React from "react";

const AddStaffPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Add New Staff</h1>
      <p className="text-gray-600">Register a new staff member here.</p>
    </div>
  );
};

export default AddStaffPage; 