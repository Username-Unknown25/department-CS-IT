import React from "react";

const AssignmentManagementPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Assignment Management</h1>
      <p className="text-gray-600">Manage assignments and submissions here.</p>
    </div>
  );
};

export default AssignmentManagementPage; 