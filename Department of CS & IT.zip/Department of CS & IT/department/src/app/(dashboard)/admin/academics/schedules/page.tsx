import React from "react";

const ScheduleManagementPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Schedule Management</h1>
      <p className="text-gray-600">Manage academic schedules and resolve conflicts here.</p>
    </div>
  );
};

export default ScheduleManagementPage; 