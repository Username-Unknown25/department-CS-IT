import React from "react";

const FacultyListPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Faculty Management</h1>
      <p className="text-gray-600">List and manage all faculty here.</p>
    </div>
  );
};

export default FacultyListPage; 