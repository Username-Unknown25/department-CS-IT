import React from "react";

const StudentGradesPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">My Grades</h1>
      <p className="text-gray-600">View your grades and transcripts here.</p>
    </div>
  );
};

export default StudentGradesPage; 