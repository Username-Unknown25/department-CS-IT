import React from "react";

const AddNewsArticlePage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Add News Article</h1>
      <p className="text-gray-600">Create and publish a new news article here.</p>
    </div>
  );
};

export default AddNewsArticlePage; 