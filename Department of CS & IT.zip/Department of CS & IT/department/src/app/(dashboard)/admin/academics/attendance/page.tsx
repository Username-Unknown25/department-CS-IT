import React from "react";

const AttendanceTrackingPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Attendance Tracking</h1>
      <p className="text-gray-600">Track and report student attendance here.</p>
    </div>
  );
};

export default AttendanceTrackingPage; 