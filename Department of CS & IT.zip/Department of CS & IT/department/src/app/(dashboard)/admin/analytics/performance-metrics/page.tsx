import React from "react";

const PerformanceMetricsPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Performance Metrics</h1>
      <p className="text-gray-600">View and analyze performance metrics here.</p>
    </div>
  );
};

export default PerformanceMetricsPage; 