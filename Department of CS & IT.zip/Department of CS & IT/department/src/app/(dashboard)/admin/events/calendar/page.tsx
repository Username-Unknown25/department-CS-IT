import React from "react";

const EventCalendarPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Event Calendar</h1>
      <p className="text-gray-600">View and manage department events calendar here.</p>
    </div>
  );
};

export default EventCalendarPage; 