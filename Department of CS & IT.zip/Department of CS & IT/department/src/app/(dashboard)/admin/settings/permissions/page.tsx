import React from "react";

const PermissionManagementPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Permission Management</h1>
      <p className="text-gray-600">Manage user roles and permissions here.</p>
    </div>
  );
};

export default PermissionManagementPage; 