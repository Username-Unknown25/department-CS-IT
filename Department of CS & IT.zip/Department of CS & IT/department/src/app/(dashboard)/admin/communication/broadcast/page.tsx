import React from "react";

const BroadcastMessagesPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Broadcast Messages</h1>
      <p className="text-gray-600">Send broadcast messages to users here.</p>
    </div>
  );
};

export default BroadcastMessagesPage; 