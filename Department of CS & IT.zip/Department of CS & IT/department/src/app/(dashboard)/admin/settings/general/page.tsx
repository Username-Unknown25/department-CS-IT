import React from "react";

const GeneralSettingsPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">General Settings</h1>
      <p className="text-gray-600">Configure general system settings here.</p>
    </div>
  );
};

export default GeneralSettingsPage; 