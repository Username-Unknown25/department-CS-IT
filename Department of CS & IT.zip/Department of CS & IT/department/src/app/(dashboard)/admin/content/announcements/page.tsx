import React from "react";

const AnnouncementsPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Announcements</h1>
      <p className="text-gray-600">View and manage department announcements here.</p>
    </div>
  );
};

export default AnnouncementsPage; 