import React from "react";

const AdminHeader: React.FC = () => {
  return (
    <header className="h-16 bg-blue-600 text-white flex items-center justify-between px-6">
      <div className="font-bold text-lg">CS & IT Admin Dashboard</div>
      <div className="flex items-center gap-4">
        {/* Notification and profile placeholders */}
        <span className="rounded-full bg-blue-800 px-3 py-1 text-sm">Admin</span>
      </div>
    </header>
  );
};

export default AdminHeader; 