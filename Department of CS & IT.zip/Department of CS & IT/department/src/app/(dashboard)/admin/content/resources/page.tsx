import React from "react";

const ResourceLibraryPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Resource Library</h1>
      <p className="text-gray-600">Access and manage department resources here.</p>
    </div>
  );
};

export default ResourceLibraryPage; 