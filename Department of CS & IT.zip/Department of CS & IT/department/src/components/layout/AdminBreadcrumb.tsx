import React from "react";

const AdminBreadcrumb: React.FC = () => {
  return (
    <nav className="text-sm text-gray-500 mb-4">
      <span>Dashboard</span> / <span>Section</span> / <span>Page</span>
    </nav>
  );
};

export default AdminBreadcrumb; 