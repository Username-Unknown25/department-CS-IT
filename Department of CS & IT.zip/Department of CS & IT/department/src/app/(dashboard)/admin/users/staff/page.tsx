import React from "react";

const StaffListPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Staff Management</h1>
      <p className="text-gray-600">List and manage all staff here.</p>
    </div>
  );
};

export default StaffListPage; 