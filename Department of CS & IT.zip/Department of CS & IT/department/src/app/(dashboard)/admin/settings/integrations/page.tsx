import React from "react";

const IntegrationsPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Third-Party Integrations</h1>
      <p className="text-gray-600">Manage and configure third-party integrations here.</p>
    </div>
  );
};

export default IntegrationsPage; 