import React from "react";

const BulkUserOperationsPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Bulk User Operations</h1>
      <p className="text-gray-600">Perform bulk operations on users here (import/export, bulk updates).</p>
    </div>
  );
};

export default BulkUserOperationsPage; 