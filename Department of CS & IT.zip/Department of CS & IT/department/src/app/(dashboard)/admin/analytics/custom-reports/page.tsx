import React from "react";

const CustomReportBuilderPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Custom Report Builder</h1>
      <p className="text-gray-600">Build and export custom reports here.</p>
    </div>
  );
};

export default CustomReportBuilderPage; 