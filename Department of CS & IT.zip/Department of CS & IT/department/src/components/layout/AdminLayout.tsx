import React from "react";
import AdminSidebar from "./AdminSidebar";
import AdminHeader from "./AdminHeader";
import AdminBreadcrumb from "./AdminBreadcrumb";

const AdminLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen flex bg-gray-50 dark:bg-neutral-900">
      {/* Sidebar */}
      <aside className="w-64 bg-white dark:bg-neutral-800 border-r border-gray-200 dark:border-neutral-700 hidden md:flex flex-col">
        <div className="p-4 font-bold text-blue-600 text-xl">Admin</div>
        <AdminSidebar />
      </aside>
      <div className="flex-1 flex flex-col min-h-screen">
        {/* Header */}
        <AdminHeader />
        <main className="flex-1 p-6">
          <AdminBreadcrumb />
          {children}
        </main>
      </div>
    </div>
  );
};

export default AdminLayout; 