import React from "react";

const AcademicReportsPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Academic Reports</h1>
      <p className="text-gray-600">Generate and view academic reports here.</p>
    </div>
  );
};

export default AcademicReportsPage; 