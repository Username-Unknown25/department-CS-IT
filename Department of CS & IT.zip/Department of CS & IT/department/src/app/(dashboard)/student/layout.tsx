import React from "react";

export default function StudentLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex bg-gray-50 dark:bg-neutral-900">
      {/* Sidebar placeholder */}
      <aside className="w-56 bg-white dark:bg-neutral-800 border-r border-gray-200 dark:border-neutral-700 hidden md:block">
        <div className="p-4 font-bold">Student Sidebar</div>
      </aside>
      <main className="flex-1 p-6">{children}</main>
    </div>
  );
} 