import React from "react";

const CurriculumManagementPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Curriculum Management</h1>
      <p className="text-gray-600">Manage curriculum and versions here.</p>
    </div>
  );
};

export default CurriculumManagementPage; 