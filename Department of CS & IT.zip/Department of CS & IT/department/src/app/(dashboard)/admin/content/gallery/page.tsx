import React from "react";

const GalleryManagementPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Image Gallery Management</h1>
      <p className="text-gray-600">Manage the department's image gallery here.</p>
    </div>
  );
};

export default GalleryManagementPage; 