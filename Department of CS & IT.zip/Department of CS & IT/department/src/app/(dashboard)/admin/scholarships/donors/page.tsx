import React from "react";

const DonorManagementPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Donor Management</h1>
      <p className="text-gray-600">Manage scholarship donors and reporting here.</p>
    </div>
  );
};

export default DonorManagementPage; 