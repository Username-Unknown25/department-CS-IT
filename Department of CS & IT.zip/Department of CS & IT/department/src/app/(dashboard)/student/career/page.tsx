import React from "react";

const StudentCareerPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Career Services</h1>
      <p className="text-gray-600">Explore career services, placements, and internships here.</p>
    </div>
  );
};

export default StudentCareerPage; 