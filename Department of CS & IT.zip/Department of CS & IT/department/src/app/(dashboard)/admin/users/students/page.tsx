import React from "react";

const StudentListPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Student Management</h1>
      <p className="text-gray-600">List and manage all students here.</p>
    </div>
  );
};

export default StudentListPage; 