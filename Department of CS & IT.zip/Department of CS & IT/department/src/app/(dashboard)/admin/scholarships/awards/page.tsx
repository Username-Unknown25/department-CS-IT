import React from "react";

const ScholarshipAwardsPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Scholarship Awards</h1>
      <p className="text-gray-600">Track and manage scholarship awards here.</p>
    </div>
  );
};

export default ScholarshipAwardsPage; 