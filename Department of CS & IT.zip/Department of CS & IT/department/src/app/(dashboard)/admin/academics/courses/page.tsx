import React from "react";

const CourseManagementPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Course Management</h1>
      <p className="text-gray-600">Manage all courses here.</p>
    </div>
  );
};

export default CourseManagementPage; 