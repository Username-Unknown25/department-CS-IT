import React from "react";

const StudentAchievementsPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">My Achievements</h1>
      <p className="text-gray-600">View your academic and extracurricular achievements here.</p>
    </div>
  );
};

export default StudentAchievementsPage; 