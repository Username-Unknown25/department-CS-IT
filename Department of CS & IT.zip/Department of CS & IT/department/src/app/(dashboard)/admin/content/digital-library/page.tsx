import React from "react";

const DigitalLibraryPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Digital Library</h1>
      <p className="text-gray-600">Access and manage digital library resources here.</p>
    </div>
  );
};

export default DigitalLibraryPage; 