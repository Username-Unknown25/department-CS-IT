import React from "react";

const CompanyPartnershipsPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Company Partnerships</h1>
      <p className="text-gray-600">Manage company partnerships and job postings here.</p>
    </div>
  );
};

export default CompanyPartnershipsPage; 