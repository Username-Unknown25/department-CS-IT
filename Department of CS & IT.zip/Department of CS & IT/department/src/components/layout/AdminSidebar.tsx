import React from "react";
import { Home, Users, BookOpen, GraduationCap, Newspaper, Calendar, Briefcase, Award, BarChart2, Bell, Settings } from "lucide-react";
import Link from "next/link";

const navLinks = [
  { href: "/app/(dashboard)/admin/dashboard", label: "Dashboard", icon: <Home size={20} /> },
  { href: "/app/(dashboard)/admin/users/students", label: "Users", icon: <Users size={20} /> },
  { href: "/app/(dashboard)/admin/academics/courses", label: "Academics", icon: <BookOpen size={20} /> },
  { href: "/app/(dashboard)/admin/faculty-management/profiles", label: "Faculty", icon: <GraduationCap size={20} /> },
  { href: "/app/(dashboard)/admin/content/news", label: "Content", icon: <Newspaper size={20} /> },
  { href: "/app/(dashboard)/admin/events/calendar", label: "Events", icon: <Calendar size={20} /> },
  { href: "/app/(dashboard)/admin/career-services/placements", label: "Career", icon: <Briefcase size={20} /> },
  { href: "/app/(dashboard)/admin/scholarships/programs", label: "Scholarships", icon: <Award size={20} /> },
  { href: "/app/(dashboard)/admin/analytics/student-analytics", label: "Analytics", icon: <BarChart2 size={20} /> },
  { href: "/app/(dashboard)/admin/communication/notifications", label: "Communication", icon: <Bell size={20} /> },
  { href: "/app/(dashboard)/admin/settings/general", label: "Settings", icon: <Settings size={20} /> },
];

const AdminSidebar: React.FC = () => {
  return (
    <nav className="p-4 space-y-2 w-full">
      {navLinks.map((link) => (
        <Link
          key={link.href}
          href={link.href}
          className="flex items-center gap-3 py-2 px-3 rounded hover:bg-blue-100 dark:hover:bg-blue-900 transition-colors text-gray-800 dark:text-gray-100"
        >
          {link.icon}
          <span>{link.label}</span>
        </Link>
      ))}
    </nav>
  );
};

export default AdminSidebar; 