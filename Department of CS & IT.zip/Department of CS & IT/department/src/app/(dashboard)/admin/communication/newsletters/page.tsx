import React from "react";

const NewsletterManagementPage: React.FC = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Newsletter Management</h1>
      <p className="text-gray-600">Create and distribute newsletters here.</p>
    </div>
  );
};

export default NewsletterManagementPage; 